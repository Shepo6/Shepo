---
name: Add-on Support Request
about: Request support for a new add-on.
title: "[ADD-ON REQUEST]"
labels: enhancement
assignees: ''

---

**What accounts does this add-on support?**
Does this add-on have compatibility with Trakt, any debrid services, or any other API keys or accounts? Which ones?

**Where is this add-on available?**
This could be a GitHub repo, a Kodi repo, or even just a file manager source.
